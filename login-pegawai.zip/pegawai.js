const pegawaiList = ["andi", "budi", "citra"];

const linkData = {
  andi: [
    { name: "Sistem Presensi", url: "https://presensi.com" },
    { name: "Email Kantor", url: "https://mail.company.com" }
  ],
  budi: [
    { name: "Dashboard Proyek", url: "https://project.com" }
  ],
  citra: [
    { name: "Form Laporan", url: "https://laporan.com" }
  ]
};
